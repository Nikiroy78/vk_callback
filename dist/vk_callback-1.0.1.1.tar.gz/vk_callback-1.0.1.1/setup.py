from setuptools import setup

setup(name='vk_callback',
      version='1.0.1.1',
      description='Develop vk callback applications and bots',
      packages=['vk_callback'],
      author_email='ill2gms@ya.ru',
      zip_safe=False)
